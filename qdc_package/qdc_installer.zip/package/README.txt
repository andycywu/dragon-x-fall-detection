Dragon X Fall Detection System - QDC 安裝包
==========================================

此安裝包包含：
1. Git 安裝程序
2. Python 3.10 安裝程序
3. 自動安裝腳本

安裝說明：
1. 雙擊運行 "RunMe.bat"
2. 等待安裝完成
3. 安裝完成後，可以通過桌面捷徑或命令運行系統

手動安裝方式：
1. 運行 Git-2.40.0-64-bit.exe 安裝 Git
2. 運行 python-3.10.11-amd64.exe 安裝 Python
3. 運行 PowerShell 腳本：
   powershell -ExecutionPolicy Bypass -File "scripts\install.ps1"

Dragon X Team
==========================================
