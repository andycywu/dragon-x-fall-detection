# Dragon X Fall Detection System
# QDC 自動安裝腳本 (PowerShell)

Write-Host "🐉 Dragon X Fall Detection System - QDC 自動安裝" -ForegroundColor Cyan
Write-Host "=========================================" -ForegroundColor Cyan

# 確定腳本路徑
$ScriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$PackagePath = Split-Path -Parent $ScriptPath

# 設置日誌檔案
$LogFile = Join-Path $ScriptPath "install_log.txt"
Start-Transcript -Path $LogFile -Append

Write-Host "📋 安裝記錄將保存到: $LogFile" -ForegroundColor Yellow

# 設置環境變數以避免互動式提示
$env:GIT_REDIRECT_STDERR = "2>&1"

# 安裝 Git
$GitInstaller = Join-Path $PackagePath "Git-2.40.0-64-bit.exe"
if (Test-Path $GitInstaller) {
    Write-Host "🔄 安裝 Git..." -ForegroundColor Yellow
    try {
        Start-Process -FilePath $GitInstaller -ArgumentList "/VERYSILENT", "/NORESTART" -Wait
        Write-Host "✅ Git 安裝成功" -ForegroundColor Green
    } catch {
        Write-Host "❌ Git 安裝失敗: $_" -ForegroundColor Red
    }
} else {
    Write-Host "❌ 找不到 Git 安裝檔: $GitInstaller" -ForegroundColor Red
}

# 安裝 Python
$PythonInstaller = Join-Path $PackagePath "python-3.10.11-amd64.exe"
if (Test-Path $PythonInstaller) {
    Write-Host "🔄 安裝 Python..." -ForegroundColor Yellow
    try {
        Start-Process -FilePath $PythonInstaller -ArgumentList "/quiet", "InstallAllUsers=1", "PrependPath=1" -Wait
        Write-Host "✅ Python 安裝成功" -ForegroundColor Green
    } catch {
        Write-Host "❌ Python 安裝失敗: $_" -ForegroundColor Red
    }
} else {
    Write-Host "❌ 找不到 Python 安裝檔: $PythonInstaller" -ForegroundColor Red
}

# 刷新環境變數
$env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")

# 驗證安裝
Write-Host "🔍 驗證安裝..." -ForegroundColor Yellow

# 檢查 Git
try {
    $GitVersion = git --version
    Write-Host "✅ Git 已安裝: $GitVersion" -ForegroundColor Green
} catch {
    Write-Host "❌ Git 驗證失敗" -ForegroundColor Red
}

# 檢查 Python
try {
    $PythonVersion = python --version
    Write-Host "✅ Python 已安裝: $PythonVersion" -ForegroundColor Green
} catch {
    Write-Host "❌ Python 驗證失敗" -ForegroundColor Red
}

# 克隆專案
Write-Host "🔍 檢查專案倉庫..." -ForegroundColor Yellow
if (-not (Test-Path "C:\dragon-x-fall-detection")) {
    Write-Host "🔄 克隆 GitHub 倉庫..." -ForegroundColor Yellow
    try {
        Set-Location C:\
        git clone https://github.com/andycywu/dragon-x-fall-detection.git
        Write-Host "✅ 倉庫克隆成功" -ForegroundColor Green
    } catch {
        Write-Host "❌ 克隆倉庫失敗: $_" -ForegroundColor Red
    }
} else {
    Write-Host "ℹ️ 倉庫已存在，正在更新..." -ForegroundColor Blue
    try {
        Set-Location C:\dragon-x-fall-detection
        git pull
        Write-Host "✅ 倉庫更新完成" -ForegroundColor Green
    } catch {
        Write-Host "❌ 更新倉庫失敗: $_" -ForegroundColor Red
    }
}

# 配置 QAI Hub
Write-Host "🔄 設置 QAI Hub 配置..." -ForegroundColor Yellow
try {
    $QaiHubDir = "$env:USERPROFILE\.qai_hub"
    if (-not (Test-Path $QaiHubDir)) {
        New-Item -Path $QaiHubDir -ItemType Directory -Force | Out-Null
    }
    
    $ConfigContent = @"
[default]
api_token = pcu8nz63e4j3nzqgy7tjzvr2dmpc01cocltahr0d
api_key = pcu8nz63e4j3nzqgy7tjzvr2dmpc01cocltahr0d
base_api_url = https://app.aihub.qualcomm.com
web_url = https://app.aihub.qualcomm.com
"@
    
    Set-Content -Path "$QaiHubDir\client.ini" -Value $ConfigContent
    Write-Host "✅ QAI Hub 配置完成" -ForegroundColor Green
} catch {
    Write-Host "❌ QAI Hub 配置失敗: $_" -ForegroundColor Red
}

# 安裝 Python 套件
if (Test-Path "C:\dragon-x-fall-detection") {
    Write-Host "🔄 安裝 Python 套件..." -ForegroundColor Yellow
    try {
        Set-Location C:\dragon-x-fall-detection
        pip install numpy opencv-python onnxruntime
        pip install -r requirements.txt
        pip install -U qai-hub qai-hub-models "protobuf==4.25.3"
        Write-Host "✅ Python 套件安裝完成" -ForegroundColor Green
    } catch {
        Write-Host "❌ Python 套件安裝失敗: $_" -ForegroundColor Red
    }
}

# 創建自動啟動捷徑
Write-Host "🔄 創建桌面捷徑..." -ForegroundColor Yellow
try {
    $WshShell = New-Object -ComObject WScript.Shell
    $Shortcut = $WshShell.CreateShortcut("$env:USERPROFILE\Desktop\Dragon X Fall Detection.lnk")
    $Shortcut.TargetPath = "cmd.exe"
    $Shortcut.Arguments = "/k cd C:\dragon-x-fall-detection && python dragon_x_fall_detection_system.py"
    $Shortcut.WorkingDirectory = "C:\dragon-x-fall-detection"
    $Shortcut.Save()
    Write-Host "✅ 桌面捷徑創建完成" -ForegroundColor Green
} catch {
    Write-Host "❌ 桌面捷徑創建失敗: $_" -ForegroundColor Red
}

Write-Host "`n🎉 Dragon X Fall Detection System - 安裝完成！" -ForegroundColor Cyan
Write-Host "您可以通過桌面捷徑或以下命令運行系統:" -ForegroundColor Cyan
Write-Host "   cd C:\dragon-x-fall-detection" -ForegroundColor White
Write-Host "   python dragon_x_fall_detection_system.py" -ForegroundColor White
Write-Host "`n完整安裝日誌可在此查看: $LogFile" -ForegroundColor Yellow

Stop-Transcript
